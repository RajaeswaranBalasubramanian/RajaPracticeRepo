package JavaProject1;

public class TestJava1 {

	public static void main(String[] args) {
         System.out.println("Hello World");
	}

}
